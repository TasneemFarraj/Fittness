﻿namespace PickFitPor.Models
{
    public class mdlImg
    {
        public IFormFile Image { get; set; }
    }
}
