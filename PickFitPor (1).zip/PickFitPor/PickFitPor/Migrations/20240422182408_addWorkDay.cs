﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PickFitPor.Migrations
{
    /// <inheritdoc />
    public partial class addWorkDay : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Cards",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WorkingDay",
                table: "Cards",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "Cards");

            migrationBuilder.DropColumn(
                name: "WorkingDay",
                table: "Cards");
        }
    }
}
