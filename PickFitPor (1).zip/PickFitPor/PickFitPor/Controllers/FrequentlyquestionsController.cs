﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PickFitPor.Data.Models;
using PickFitPor.Models;
using PickFitPor.Migrations;

namespace PickFitPor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FrequentlyquestionsController : ControllerBase
    {
        public FrequentlyquestionsController(AppDbContextcs Db)
        {
            _Db = Db;
        }
        private readonly AppDbContextcs _Db;

        [HttpGet]
        public async Task<IActionResult> GetQuestions()
        {
            var Frequentlie = await _Db.Frequentlies.ToListAsync();
            return Ok(Frequentlie);

        }
        [HttpPost]
        public async Task<IActionResult> AddQuestions(string Questions, string Answer)
        {
            var Frequentlies = new Frequently_questions
            {
                Question = Questions,
                Answer = Answer,
             
            };
            await _Db.Frequentlies.AddAsync(Frequentlies);
            _Db.SaveChanges();
            return Ok(Frequentlies);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateQuestions(Frequently_questions Questions)
        {
            var Questionss = await _Db.Frequentlies.SingleOrDefaultAsync(Frequentlies => Frequentlies.Id == Frequentlies.Id);
            if (Questionss == null)
            {
                return NotFound($"questions");
            }

            Questionss.Question= Questions.Question;
            Questionss.Answer = Questions.Answer;
            _Db.SaveChanges();
            return Ok(Questionss); 
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> RemoveQuestions(int id)
        {
            var Frequentlie = await _Db.Frequentlies.SingleOrDefaultAsync(x => x.Id == id);
            if (Frequentlie == null)
            {
                return NotFound($"questions with Id {id} not found.");
            }
            _Db.Frequentlies.Remove(Frequentlie);
            await _Db.SaveChangesAsync();
            return Ok(Frequentlie);
        }
    }
}
