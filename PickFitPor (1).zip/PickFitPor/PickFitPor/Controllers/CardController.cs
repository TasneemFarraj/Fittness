﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PickFitPor.Data.Models;
using PickFitPor.Models;


namespace PickFitPor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardController : ControllerBase
    {
        public CardController(AppDbContextcs Db)
        {
            _Db = Db;
        }
        private readonly AppDbContextcs _Db;

        [HttpGet]
        public async Task<IActionResult> Getcard()
        {
            var card = await _Db.Cards.ToListAsync();
            return Ok(card);
        }
        [HttpPost]
        public async Task<IActionResult> AddCard( string Name, string Specialty, string Phone, string Addrres, string Rating,string img,string Email,string WorkingDay)
        {
            var carda = new Carda
            { 
               Name = Name,
               Specialty = Specialty,
                Phone = Phone,
                Addrres = Addrres,
                Rating = Rating,
                Img = img,
                Email = Email,
                WorkingDay = WorkingDay
            };
            await _Db.Cards.AddAsync(carda);
            _Db.SaveChanges();
            return Ok(carda);
        }
        [HttpPut]
        public async Task<IActionResult> UpdateCard(Carda Cards)
        {
            var ccard = await _Db.Cards.SingleOrDefaultAsync(ccard => ccard.Id == ccard.Id);
            if (ccard == null)
            {
                return NotFound($"Cards");
            }
          
            ccard.Name = Cards.Name;
            ccard.Specialty = Cards.Specialty;
            ccard.Phone = Cards.Phone;
            ccard.Addrres = Cards.Addrres;
            ccard.Rating = Cards.Rating;
            ccard.Img=ccard.Img;
            ccard.Email = ccard.Email;
            ccard.WorkingDay = ccard.WorkingDay;

            _Db.SaveChanges();
            return Ok(ccard);
        }
        [HttpDelete("id")]
        public async Task<IActionResult> Removcard(int id)
        {
            var c = await _Db.Cards.SingleOrDefaultAsync(x => x.Id == id);

            if (c == null)
            {
                return NotFound($"Card Id {id} not exisys");
            }
            _Db.Cards.Remove(c);
            _Db.SaveChanges();
            return Ok(c);
        }
    }
}
