﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PickFitPor.Data.Models;
using PickFitPor.Models;

namespace PickFitPor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        public HomeController(AppDbContextcs Db)
        {
            _Db = Db; 
        }
        private readonly AppDbContextcs _Db;

        [HttpGet]
        public async Task<IActionResult> GetHome()
        {
            var home = await _Db.Home.ToListAsync();
            return Ok(home);

        }
        [HttpPost]
        public async Task<IActionResult> AddHome(string hom)
        {
            hom h = new() {Name = hom };
            await _Db.Home.AddAsync(h);
            _Db.SaveChanges();
            return Ok(h);
        }
        [HttpPut]
        public async Task<IActionResult> UpdateHome(hom home)
        {
            var h = await _Db.Home.SingleOrDefaultAsync(h => h.Id == home.Id);
            if (h == null)
            {
                return NotFound($"home ");           
            }
            h.Name = home.Name;
            _Db.SaveChanges();
            return Ok(h);
        }
        [HttpDelete("id")]
        public async Task<IActionResult> RemoveCategory(int id)
        {
            var c = await _Db.Home.SingleOrDefaultAsync(x => x.Id == id);

            if (c == null)
            {
                return NotFound($"Category Id {id} not exisys");
            }
            _Db.Home.Remove(c);
            _Db.SaveChanges();
            return Ok(c);
        }
    }
}

