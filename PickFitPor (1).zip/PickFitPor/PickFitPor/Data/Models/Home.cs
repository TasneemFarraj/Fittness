﻿using System.ComponentModel.DataAnnotations;

namespace PickFitPor.Data.Models
{
    public class hom
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
