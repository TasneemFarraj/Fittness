﻿using Microsoft.AspNetCore.Identity;

namespace PickFitPor.Data.Models
{
    public class AppUser : IdentityUser
    {
    }
}
