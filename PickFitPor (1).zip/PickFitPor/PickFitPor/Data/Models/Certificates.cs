﻿using System.ComponentModel.DataAnnotations;

namespace PickFitPor.Data.Models
{
    public class Certificates
    { 
        [Key]
        public int Id { get; set; }
        public byte[]? Image { get; set; }
    }
}

