﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PickFitPor.Data.Models;

namespace PickFitPor.Models
{
    public class AppDbContextcs :IdentityDbContext<AppUser>
    {
        public AppDbContextcs(DbContextOptions<AppDbContextcs> options) : base(options) 
        {

        }
        public DbSet<hom> Home { get; set; }

        public DbSet<Carda> Cards { get; set; }
        public DbSet<Frequently_questions> Frequentlies { get; set; }

        public DbSet<Certificates> Certificatesss { get; set; }
     

    }
}
